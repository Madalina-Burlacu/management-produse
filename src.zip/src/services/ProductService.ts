import { db } from "../config/firestore";
import {
    collection,
    addDoc,
    getDocs,
    deleteDoc,
    doc,
    setDoc,
} from "firebase/firestore";
import { Product } from "../interface/models/Product";
import { IProductInterface } from "../interface/services/IProductInterface";

class ProductService implements IProductInterface {
    async getAllProducts(): Promise<Product[]> {
        const querySnapshot = await getDocs(collection(db, "products"));
        return querySnapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
        })) as Product[];
    }

    async addProduct(product: Product): Promise<void> {
        const imgFileUrl = await addDoc(collection(db, "products"), product);
    }

    async editProduct(id: string, updatedProduct: Product): Promise<void> {
        await setDoc(doc(db, "products", id), updatedProduct);
    }

    async deleteProduct(id: string): Promise<void> {
        await deleteDoc(doc(db, "products", id));
    }
}

// daca export doar clasa trebuie sa creez o instanta manual
export default new ProductService();
