export interface Product {
    id?: string;
    productName: string;
    units: number;
    price: number;
    imgFile: string;
}
